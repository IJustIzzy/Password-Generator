﻿bool exit = false;

while (exit == false)
{
    Console.WriteLine("Press enter to generate password");
    Console.ReadLine();

    string[] password = new string[9];

    for (int i = 0; i <= 8; i++)
    {
        int num = new Random().Next(33, 127);
        char letter = (char)num;
        password[i] = letter.ToString();
    }

    int count = 0;
    const string symbols = "!£$%^&*()_+{}:@~<>?¬|-=[];'#,./'";
    string strength = string.Empty;

    Console.WriteLine("Your password is:");
    foreach (string words in password)
    {
        if (words == words.ToUpper())
        {
            count += 10;
        }
        foreach (char letters in symbols)
        {
            if (words.ToString() == letters.ToString())
            {
                count += 5;
            }
        }
        Console.Write(words);
    }
    Console.WriteLine("\nThe strength score of the password is {0}", count);

    if (count >= 40)
    {
        strength = "strong";
    }
    else if (count >= 25)
    {
        strength = "medium";
    }
    else
    {
        strength = "weak";
    }
    Console.WriteLine("The password has a {0} strength", strength);
}